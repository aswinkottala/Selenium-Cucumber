package utilities;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;


/**
 * Created by aswin on 11/12/2017.
 */
public class DriverFactory {

    //This method returns a WebDriver
    public static WebDriver open(String browserType) {
        if (browserType.equalsIgnoreCase("Chrome")) {
            System.setProperty("webdriver.chrome.driver", "C:\\Selenium-Cucumber\\chromedriver.exe");
            return new ChromeDriver();
        } else   {
            System.setProperty("webdriver.ie.driver", "C:\\Selenium-Cucumber\\IEDriverServer.exe");
            return new InternetExplorerDriver();
        }
    }
}
