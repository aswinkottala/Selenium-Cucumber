package dvla.Pages;

import cucumber.api.java.After;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


/**
 * Created by aswin on 12/12/2017.
 */
public class MySharedClass {
    private WebDriver driver = null;
    public String id = "9393";

    @Before
    public void startBrowser(){

        System.setProperty("webdriver.chrome.driver","C:\\Selenium-Cucumber\\chromedriver.exe");
        if (driver==null)
            driver = new ChromeDriver();
    }

    public WebDriver getDriver(){
        return this.driver;
    }


    @After
    public void closeBrowser(Scenario scenario){

        if (scenario.isFailed()) {
            scenario.embed(((TakesScreenshot)driver).getScreenshotAs(OutputType.BYTES), "image/png");
            scenario.write("Scenario failed");
        }else{
            scenario.write("Scenario passed");
        }

        driver.close();
        driver.quit();
        driver = null;
    }
}
