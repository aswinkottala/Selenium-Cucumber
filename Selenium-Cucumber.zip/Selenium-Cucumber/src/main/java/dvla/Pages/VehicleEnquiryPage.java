package dvla.Pages;

import gherkin.lexer.No;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 * Created by aswin on 11/12/2017.
 */
public class VehicleEnquiryPage {

    //WebDriver driver;

    //Vehicle Enquiry Page Objects

    WebDriver driver;


    //
    public static By regNo = By.xpath("//*[@id='Vrm']");

    public static By continueBtn = By.xpath("//*[contains(text(),'Continue')]");

    public void setVehicleRegistrationNo(String regno)
    {
        System.out.println("I enter the vehicle registration no");
        //Enter the vehicle registration no in the registration no textbox
        driver.findElement(regNo).sendKeys(regno.trim());
    }

    public void clickContinue()
    {
        System.out.println("I click on the continue button");
        //Click on the Continue button
        driver.findElement(continueBtn).click();
    }

}
