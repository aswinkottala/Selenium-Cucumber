package dvla.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import static org.junit.Assert.assertEquals;

/**
 * Created by aswin on 11/12/2017.
 */
public class ConfirmVehiclePage {

    WebDriver driver;



    public static By regNoActual = By.xpath("//*[@id='pr3']/div/ul/li[1]/span[2]");

    public static By makeActual = By.xpath("//*[@id='pr3']/div/ul/li[2]/span[2]/strong");

    public static By colourActual = By.xpath("//*[@id='pr3']/div/ul/li[3]/span[2]/strong");

    public void checkVehicleDetails(String registrationNo,String make,String colour)
    {
// Code to check the registration no is displayed as expected
        assertEquals("Check Registration No", registrationNo.trim(), driver.findElement(regNoActual).getText().trim());

        // Code to check the make is displayed as expected
        assertEquals("Check make", make.trim(), driver.findElement(makeActual).getText().trim());

        // Code to check the colour is displayed as expected
        assertEquals("Check colour", colour.trim(), driver.findElement(colourActual).getText().trim());
    }

    /*public ConfirmVehiclePage(WebDriver driver){
            this.driver=driver;

    }*/
}
