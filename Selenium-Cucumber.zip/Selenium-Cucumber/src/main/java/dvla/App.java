package dvla;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import javax.activation.MimetypesFileTypeMap;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import static org.apache.commons.io.FilenameUtils.getExtension;

public class App
{
    public static void main( String[] args )
    {

        String browserType = "chrome";
        //String url="\"https://vehicleenquiry.service.gov.uk/\"";
        //String browserType="IE";

        try {
            // Open the Excel file
            FileInputStream fis = new FileInputStream("C:\\Selenium-Cucumber\\TestData\\VehicleDetails.xlsx");
            // Access the required test data sheet
            XSSFWorkbook wb = new XSSFWorkbook(fis);
            XSSFSheet sheet = wb.getSheet("testdata");
            // Loop through all rows in the sheet
            // Start at row 1 as row 0 is our header row
            for(int count = 1;count<=sheet.getLastRowNum();count++){
                XSSFRow row = sheet.getRow(count);

                //XSSFRow sourceRow = sourceSheet.getRow(row);
                XSSFCell RegNo=row.getCell(0);
                XSSFCell Vehmake=row.getCell(1);
                XSSFCell Vehcolour=row.getCell(1);


                String RegistrationNo = RegNo.getStringCellValue();
                String VehicleMake = Vehmake.getStringCellValue();
                String VehicleColour = Vehmake.getStringCellValue();

                System.out.println("Registration No of row :"+count+"   "+ RegistrationNo);
                System.out.println("Vehicle Make of row : "+count+"   "+VehicleMake);
                System.out.println("Vehicle Colour of row : "+count+"   "+ VehicleColour);

               /* System.out.println("Running test case " + row.getCell(0).toString());
                System.out.println("Running test case " + row.getCell(1).toString());
                System.out.println("Running test case " + row.getCell(2).toString());*/
                // Run the test for the current test data row
               // runTest(row.getCell(1).toString(),row.getCell(2).toString());
            }
            //Close file
            fis.close();

            File folder = new File("C:\\Selenium-Cucumber\\TestData");
            File[] listOfFiles = folder.listFiles();

            for (int i = 0; i < listOfFiles.length; i++) {
                if (listOfFiles[i].isFile()) {
                    System.out.println("File " + listOfFiles[i].getName());
                } else if (listOfFiles[i].isDirectory()) {
                    System.out.println("Directory " + listOfFiles[i].getName());
                }
            }

            String fileName = "C:\\Selenium-Cucumber\\TestData\\VehicleDetails.xlsx";
            MimetypesFileTypeMap mimeTypesMap = new MimetypesFileTypeMap();

            //only by file name
            String mimeType = mimeTypesMap.getContentType(fileName);

            System.out.println(mimeType);

            //or by actual File instance
            File file = new File(fileName);
            mimeType = mimeTypesMap.getContentType(file);

            System.out.println(getFileSizeBytes(file));
            System.out.println(getFileSizeKiloBytes(file));
            System.out.println(getFileSizeMegaBytes(file));
            // Code to get the file extension
            System.out.println(getExtension(file.getName()));

        } catch (IOException e) {
            System.out.println("Test data file not found");
        }
        System.out.println( "Hello World!" );
    }

    //Function to calculate the file size in mb
    private static String getFileSizeMegaBytes(File file) {
        return (double) file.length() / (1024 * 1024) + " mb";
    }
    //Function to calculate the file size in kb
    private static String getFileSizeKiloBytes(File file) {
        return (double) file.length() / 1024 + "  kb";
    }
    //Function to calculate the file size in bytes
    private static String getFileSizeBytes(File file) {
        return file.length() + " bytes";
    }

}
