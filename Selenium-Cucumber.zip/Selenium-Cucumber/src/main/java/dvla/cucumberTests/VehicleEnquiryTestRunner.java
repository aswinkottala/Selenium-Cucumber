package dvla.cucumberTests;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;
/**
 * Created by aswin on 11/12/2017.
 */

@RunWith(Cucumber.class)
@CucumberOptions(features ="features", glue = "dvla",plugin = {"html:target/myreport" })

public class VehicleEnquiryTestRunner {




}
