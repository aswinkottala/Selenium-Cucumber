package dvla.stepImplementations;

import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import dvla.Pages.ConfirmVehiclePage;
import dvla.Pages.MySharedClass;
import dvla.Pages.VehicleEnquiryPage;
//import org.junit.After;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import static dvla.Pages.VehicleEnquiryPage.continueBtn;
import static dvla.Pages.VehicleEnquiryPage.regNo;
import static org.junit.Assert.assertEquals;

/**
 * Created by aswin on 11/12/2017.
 */
@SuppressWarnings("ALL")
public class BDDVehicleEnquiryTest  {

    WebDriver driver;
    private String regno;

    //Create an object of a class VehicleEnquiryPage to call the methods within that class
    VehicleEnquiryPage vehEnqPageObj = new VehicleEnquiryPage();

    //Create an object of a class ConfirmVehiclePage to call the methods within that class
    ConfirmVehiclePage confirmVehPageObj = new ConfirmVehiclePage();


    @Given("^I have the dvla url and I navigate to the vehicle enquiry page$")
    public void i_have_the_dvla_url() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        System.out.println("I have the dvla url and I navigate to the vehicle enquiry page");

        driver=utilities.DriverFactory.open("Chrome");
        driver.get("https://vehicleenquiry.service.gov.uk/");
        //driver.manage().window().maximize();
    }

    @When("^I enter the vehicle registration no(.*)$")
    public void i_enter_the_vehicle_registration_no(String regno) throws Throwable {
       //Call the function setVehicleRegistrationNo from the class VehicleEnquiryPage and pass the registgration no to the function which enters a registration no value into the text box
        vehEnqPageObj.setVehicleRegistrationNo(regno);
        //driver.findElement(regNo).sendKeys(regno.trim());
    }

    @When("^I click on the continue button$")
    public void i_click_on_the_continue_button() throws Throwable {
        //Call the function clickContinue from the class VehicleEnquiryPage to click the continue button
        vehEnqPageObj.clickContinue();
        //driver.findElement(continueBtn).click();
    }

    @Then("^validate the registration no make and colour(.*),(.*),(.*)$")
    public void validate_the_registration_no_make_and_colour(String regno,String make,String colour) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        System.out.println("validate the registration no, make and colour");
        // Call the function checkVehicleDetails from the class ConfirmVehiclePage which checks the details of the confirmation page
        confirmVehPageObj.checkVehicleDetails(regno,make,colour);

       /*// Code to check the registration no is displayed as expected
        assertEquals("Check Registration No", regno.trim(), driver.findElement(confirmVehPageObj.regNoActual).getText().trim());

        // Code to check the make is displayed as expected
        assertEquals("Check make", make.trim(), driver.findElement(confirmVehPageObj.makeActual).getText().trim());

        // Code to check the colour is displayed as expected
        assertEquals("Check colour", colour.trim(), driver.findElement(confirmVehPageObj.colourActual).getText().trim());
        */
      }
    @After
      public void tearDown(){
        //Close the current browser
        driver.close();
        //Close All browsers
        driver.quit();

      }
}
