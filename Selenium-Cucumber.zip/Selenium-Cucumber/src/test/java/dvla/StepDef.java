package dvla;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 * Created by aswin on 11/12/2017.
 */
public class StepDef {

  /*  @Given("^I have the dvla url$")
    public void i_have_the_dvla_url() throws Throwable {
        // Write code here that turns the phrase above into concrete actions



    }

    @Given("^I navigate to the vehicle enquiry page$")
    public void i_navigate_to_the_vehicle_enquiry_page() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

    }

    @When("^I enter the vehicle registration no$")
    public void i_enter_the_vehicle_registration_no() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

    }

    @When("^I click on the continue button$")
    public void i_click_on_the_continue_button() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

    }

    @Then("^validate the registration no make and colour$")
    public void validate_the_registration_no_make_and_colour() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

    }
*/


}
